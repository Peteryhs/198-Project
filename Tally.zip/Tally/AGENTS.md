# Tally design and development

Tally is an Arduino-first measurement app. Preserve the Wi-Fi/TCP sensor workflow.

For UI/UX work, load the Material Design 3 UI skill at
`/Users/jeevan/.codex/skills/material-design-3-ui/SKILL.md`, including
`references/m3-expressive.md`, `references/accessibility.md`, and relevant component references.
Source: https://github.com/skydashnet/material-design-3-ui-skill
If the local skill is unavailable, consult current official Material and Android documentation.

The user requires Material 3 Expressive design coherence. Use semantic theme roles,
intentional typography and shape contrast, adaptive layouts, and restrained motion.
Emphasize Record/Pause; keep scientific plots and tables calm and legible. Use standard
Material controls for navigation and selection. Keep axes distinguishable beyond color.

The project uses Material3 1.5.0-rc01, authorized by the user for its public Expressive APIs.
Use MaterialExpressiveTheme and supported component shape/motion APIs; preserve the custom typography.
Other toolchain dependencies remain pinned in Gradle.

Use the exact Ink/Paper/Oat/Clay/White palette in Color.kt. Keep dynamic color disabled.
Preserve Atkinson Hyperlegible for UI typography and monospace tabular numeric readouts.
Sensor plugs must remain data-driven; preserve legacy protocol and recording compatibility.

Verify changes with assembleDebug, testDebugUnitTest, and lintDebug. Use the installed Java 21
runtime. The toolchain uses AGP 9.1.1, Gradle 9.3.1, and Kotlin/Compose 2.4.10.
Do not overwrite saved measurements or silently replace physical readings with demo data.
