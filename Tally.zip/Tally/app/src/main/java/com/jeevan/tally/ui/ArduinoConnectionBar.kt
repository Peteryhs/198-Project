package com.jeevan.tally.ui

import android.content.Context
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.jeevan.tally.sensors.ArduinoLink
import com.jeevan.tally.ui.theme.*

@Composable
fun ArduinoConnectionBar(context: Context, modifier: Modifier = Modifier) {
    val prefs = remember { context.getSharedPreferences("tally_prefs", Context.MODE_PRIVATE) }
    var host by remember { mutableStateOf(prefs.getString("arduino_host", "192.168.240.1") ?: "") }
    var port by remember { mutableStateOf(prefs.getString("arduino_port", "5555") ?: "") }
    val status by ArduinoLink.status.collectAsState()
    val error by ArduinoLink.errorMessage.collectAsState()
    val connected = status == ArduinoLink.Status.CONNECTED
    val connecting = status == ArduinoLink.Status.CONNECTING
    val validPort = port.toIntOrNull()?.let { it in 1..65535 } == true
    val label = when (status) {
        ArduinoLink.Status.CONNECTED -> "Connected"
        ArduinoLink.Status.CONNECTING -> "Connecting"
        ArduinoLink.Status.ERROR -> "Connection failed"
        else -> "Not connected"
    }
    Card(modifier.fillMaxWidth(), shape = MaterialTheme.shapes.extraLarge, 
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatusLed(color = if (connected) StatusConnected else if (status == ArduinoLink.Status.ERROR) MaterialTheme.colorScheme.error else StatusOff, pulsing = connecting)
                Text("Arduino", style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
            }
            if (!connected) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(host, { host = it }, label = { Text("IP address") }, singleLine = true,
                        enabled = !connecting, modifier = Modifier.weight(2f), shape = RoundedCornerShape(8.dp))
                    OutlinedTextField(port, { port = it.filter(Char::isDigit).take(5) }, label = { Text("Port") },
                        singleLine = true, enabled = !connecting, isError = port.isNotEmpty() && !validPort,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f), shape = RoundedCornerShape(8.dp))
                }
                if (status == ArduinoLink.Status.ERROR) Text(error ?: "Check the address and Wi-Fi connection.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            } else Text("${host.trim()}:$port", style = ReadoutSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (connected || connecting) OutlinedButton(onClick = { ArduinoLink.disconnect() }, shape = RoundedCornerShape(8.dp), modifier = Modifier.fillMaxWidth()) {
                Text(if (connecting) "Cancel connection" else "Disconnect")
            } else Button(onClick = {
                prefs.edit().putString("arduino_host", host.trim()).putString("arduino_port", port).apply()
                ArduinoLink.connect(host.trim(), port.toInt())
            }, enabled = host.isNotBlank() && validPort, shape = MaterialTheme.shapes.extraLarge, modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp)) { Text("Connect to board") }
        }
    }
}
